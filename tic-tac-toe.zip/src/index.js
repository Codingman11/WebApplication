import "./styles.css";

document.getElementById("header").innerHTML = `
<head>
<title>Parcel Sandbox</title>
<meta charset="UTF-8" />
</head>

<body>
<h1>Welcome to my TicTacToe game</h1>
<div id="app"></div>
  <script src="src/index.js"> </script>
  
</body>`;
