import "./styles.css";

function createArray() {
  var array = [];
  for (let i = 0; i < 5; i++) {
    array[i] = new Array(5);
    for (let j = 0; j < 5; j++) {
      array[i][j] = " ";
    }
  }

  return array;
}

function addTable(array) {
  var x = 0;

  var cTable = document.createElement("table");
  for (var i = 0; i < 5; i++) {
    var addTr = document.createElement("tr");

    for (var j = 0; j < 5; j++) {
      var addTd = document.createElement("td");
      addTd.setAttribute("id", "id" + x);
      var node = document.createTextNode(array[i][j]);
      addTd.appendChild(node);
      addTr.appendChild(addTd);
      x++;
    }
    var cTable = document.createElement("table");
    cTable.appendChild(addTr);
    var tab = document.getElementById("board");
    tab.appendChild(cTable);
  }
}

var array = createArray();
addTable(array);
